import React, { useEffect, useState } from "react";
import CounterDisplay from "./CounterDisplay";
import CounterControls from "./CounterControls";

function CounterPage() {
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    if (counter > 5) {
      console.log("Counter is greater than 5");
    }
  }, [counter]);

  useEffect(() => {
    if (counter < 0) {
      setCounter(0);
    }
  }, [counter]);

  return (
    <div>
      <CounterDisplay count={counter} />
      <CounterControls
        increment={() => setCounter((prev) => prev + 1)}
        decrement={() => setCounter((prev) => prev - 1)}
      />
      {counter > 5 && <p>Counter is greater than 5</p>}
    </div>
  );
}

export default CounterPage;