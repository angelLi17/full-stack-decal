import React, { useContext } from "react";
import { ThemeContext } from "../../context/ThemeContext";
import "./Home.css";

function Home() {
  const {theme} = useContext(ThemeContext);

  return (
  <div className={theme === "dark" ? "home home-dark" : "home home-light"}>
    <h1>welcome~</h1>
  </div>
  );
}

export default Home;