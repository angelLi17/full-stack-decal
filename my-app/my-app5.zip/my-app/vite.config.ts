import react from '@vitejs/plugin-react'
import { defineConfig, transformWithOxc, type Plugin } from 'vite'

// The assignment (written for create-react-app) puts JSX in .js files.
// Vite only parses JSX in .jsx/.tsx files, so compile our src/*.js files as JSX first.
function jsxInJs(): Plugin {
  return {
    name: 'jsx-in-js',
    enforce: 'pre',
    async transform(code, id) {
      if (!/\/src\/.*\.js$/.test(id)) return null
      return transformWithOxc(code, id, { lang: 'jsx', jsx: { runtime: 'automatic' } })
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [jsxInJs(), react()],
  optimizeDeps: {
    rolldownOptions: { moduleTypes: { '.js': 'jsx' } },
  },
})
